from django.apps import AppConfig


class ShareConfig(AppConfig):
    name = 'share'
