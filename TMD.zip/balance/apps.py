from django.apps import AppConfig


class BalanceConfig(AppConfig):
    name = 'balance'
