from django.contrib import admin

# Register your models here.
admin.site.site_header='TMD ADMIN PANEL'
