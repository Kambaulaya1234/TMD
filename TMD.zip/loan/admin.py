from django.contrib import admin
from .models import Loan
# Register your models here.
admin.site.register(Loan)
